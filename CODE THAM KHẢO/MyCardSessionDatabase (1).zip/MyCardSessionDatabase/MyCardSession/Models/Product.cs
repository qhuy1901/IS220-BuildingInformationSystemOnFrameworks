﻿using System;
namespace MyCardSession.Models
{
    public class Product
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public string Photo { get; set; }
        public Product()
        {
        }
    }
}
