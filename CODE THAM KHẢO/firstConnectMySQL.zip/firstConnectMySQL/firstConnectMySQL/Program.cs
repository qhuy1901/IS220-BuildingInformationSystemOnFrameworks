﻿using System;
using System.Data.Common;
using MySql.Data.MySqlClient;

namespace firstConnectMySQL
{
    class Program
    {
        static void Main(string[] args)
        {
            string host = "localhost";
            int port = 3306;
            string database = "quanlycasi1";
            string username = "root";
            string password = "";

            String connString = "Server=" + host + ";Database=" + database
              + ";port=" + port + ";User Id=" + username + ";password=" + password;

            //tạo đối tượng connection 
            MySqlConnection conn = new MySqlConnection(connString);

            //Mở connecttion
            try
            {
                conn.Open();

            }
            catch (MySqlException e)
            {
                switch (e.Number)
                {
                    case 0:
                        Console.WriteLine("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        Console.WriteLine("Invalid username/password, please try again");
                        break;
                }
                //Console.WriteLine("Error: " + e.Message);
            }
            string sql = "Select * from casi";
            // Tạo một đối tượng Command.
            MySqlCommand cmd = new MySqlCommand();
            // Liên hợp Command với Connection.
            cmd.Connection = conn;
            cmd.CommandText = sql;
            using (DbDataReader reader = cmd.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    Console.WriteLine("Id\tName");
                    while (reader.Read())
                    {
                        // Chỉ số (index) của cột id trong câu lệnh SQL.
                        int indexid = reader.GetOrdinal("id"); // 0
                        int id = Convert.ToInt32(reader.GetValue(indexid));
                        
                        /*int id = reader.GetInt32(0);
                        Console.Write(id+"\t");
                        */
                        int IndexName = reader.GetOrdinal("Name");
                        String Name = reader.GetString(IndexName);

                        Console.WriteLine(Name);
                    }
                }
            }
            conn.Close();
        }
    }
}
