﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
namespace MyCookies.Controllers
{
    public class CookiesController : Controller
    {
        public IActionResult Index()
        {
            ViewData["name"] = Request.Cookies["name"];
            ViewData["age"] = Request.Cookies["age"];
            return View();
        }
    }
}
