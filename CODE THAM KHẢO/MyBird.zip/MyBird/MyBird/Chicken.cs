﻿using System;
namespace MyBird
{
    public class Chicken:Bird
    {
        public new void Fly() => Console.WriteLine("Chicken cannot Fly");
    }
}
