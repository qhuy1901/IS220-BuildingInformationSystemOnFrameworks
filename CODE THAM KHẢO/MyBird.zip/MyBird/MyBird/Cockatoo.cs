﻿using System;
namespace MyBird
{
    public class Cockatoo:Parrot
    {
        public Cockatoo() => Console.WriteLine("Cockatoo created");
        public void Dance() => Console.WriteLine("Cockatoo is dancing");
    }
}
