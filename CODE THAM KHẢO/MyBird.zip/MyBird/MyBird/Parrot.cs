﻿using System;
namespace MyBird
{
    public class Parrot:Bird
    {
        public Parrot() => Console.WriteLine("Parrot created");
        public Parrot(int weight) : base(weight) { }
        public void Speak() {
            //base.Fly();
            Console.WriteLine("Parrot is speaking"); }
    }
}
