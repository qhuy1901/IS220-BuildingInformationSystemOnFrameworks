﻿using System;
namespace MyBird
{
    public class Bird
    {
        private int _weight;
        public int Weight
        {
            get => _weight;
            set
            {
                if (value > 0)
                    _weight = value;
            }
        }
        public Bird() => Console.WriteLine($"Bird created");
        public Bird(int weight)
        {
            _weight = weight;
            Console.WriteLine($"Bird created, {_weight} gr.");
        }
        public void Feed() => _weight += 10;
        public void Fly() => Console.WriteLine("Bird is flying");

    }
}
