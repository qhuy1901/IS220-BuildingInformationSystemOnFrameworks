﻿using System;

namespace MyBird
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Console.WriteLine("----Bird:----");
            Bird bird = new Bird(50) { Weight = 100 };
            bird.Feed();
            Console.WriteLine($"Weight {bird.Weight}");
            bird.Fly();
            */
            Console.WriteLine("----Parrot----");
            Parrot parrot = new Parrot(200);
            parrot.Feed();
            Console.WriteLine($"Weight: {parrot.Weight}");
            parrot.Fly();
            parrot.Speak();
            /*
            Console.WriteLine("----Cockatoo:----");
            Cockatoo cockatoo = new Cockatoo() { Weight = 300 };
            cockatoo.Feed();
            Console.WriteLine($"Weight: {cockatoo.Weight}");
            cockatoo.Fly();
            cockatoo.Speak();
            cockatoo.Dance();*/

            /*Chicken bird = new Chicken { Weight = 100 };
            bird.Fly();*/

        }
    }
}
